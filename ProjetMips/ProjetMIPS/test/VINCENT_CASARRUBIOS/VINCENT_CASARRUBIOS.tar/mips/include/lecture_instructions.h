void lecture_operateur (char* instruction, char * operateur);
void lecture_operandeR (char* instruction, int * operande);
void lecture_operandeI (char* instruction, int* operande);
void lecture_operandeJ (char* instruction, int* target);