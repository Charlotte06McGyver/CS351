#include <stdio.h>
#include <stdlib.h>

void fatal(char *);
void *ec_malloc(unsigned int);
