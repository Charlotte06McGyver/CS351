#include <stdio.h>
#include <stdlib.h>

void gotohexa(char *, char*);
char tohexa(int);
int binaryhexa(char *);
int byte(int);
void *bit(int, int, char*);
