/**
  * CS351 - Corrections de TP 2016-2017
  * Projet TP3-1
  * TP2-4.c
  * Eva Gerbert-Gaillard
  */

#ifndef __jeu_h__
#define __jeu_h__
#include <stdio.h>

void jeuMultiPoints ();

#endif
