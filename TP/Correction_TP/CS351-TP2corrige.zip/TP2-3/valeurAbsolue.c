#include <stdio.h>
#include <stdlib.h>
int valeur_absolue(int a){
	return abs(a);
}