
int quotient(int a,int b);