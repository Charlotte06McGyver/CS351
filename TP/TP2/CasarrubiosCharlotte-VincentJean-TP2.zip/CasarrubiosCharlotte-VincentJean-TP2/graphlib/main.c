#include "dessine.h"


int main(){
    dessineCarre(10, 10 , 10);

}
