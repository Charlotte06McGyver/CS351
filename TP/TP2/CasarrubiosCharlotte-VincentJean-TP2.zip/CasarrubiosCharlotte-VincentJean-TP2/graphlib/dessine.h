#include "graphlib.h"

void dessineCarre(float x1,float y1 , float taille);
void dessineCarreDiagonale(float x1,float y2, float taille);
