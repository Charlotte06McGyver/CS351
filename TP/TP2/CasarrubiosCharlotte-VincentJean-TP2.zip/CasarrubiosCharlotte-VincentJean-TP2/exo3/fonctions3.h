//Fichier qui va decrire chaque fonction utile au programme

int quotient(int a, int b);
int reste (int a, int b);
int valeurAbsolue (int a);
int pgcd(int a , int b); //fonction codee dans le TP1
int ppcm(int a, int b);
int puissanceMB(int x, int n);
int sommeDesImpairs(int d, int f);
int estUneDecompositionDe(int d, int f);