#include <stdio.h>
#include <stdlib.h>

int valeurAbsolue (int a){

    if (a<0){
        a=-a;
    }
    return a;
}
